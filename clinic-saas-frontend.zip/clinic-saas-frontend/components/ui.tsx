import { ArrowRight } from 'lucide-react'
import { ReactNode } from 'react'

export function Button({ children, secondary = false }: { children: ReactNode; secondary?: boolean }) {
  return (
    <button
      className={
        secondary
          ? 'inline-flex items-center gap-2 rounded-full border border-line px-5 py-3 text-sm font-medium text-ink transition hover:bg-slate-50'
          : 'inline-flex items-center gap-2 rounded-full bg-ink px-5 py-3 text-sm font-medium text-white transition hover:opacity-90'
      }
    >
      {children}
      {!secondary && <ArrowRight size={16} />}
    </button>
  )
}

export function SectionHeader({ eyebrow, title, copy }: { eyebrow: string; title: string; copy: string }) {
  return (
    <div className="mb-12 space-y-4">
      <span className="badge">{eyebrow}</span>
      <h2 className="section-title">{title}</h2>
      <p className="section-copy">{copy}</p>
    </div>
  )
}
