# ClinicFlow Frontend

Frontend em Next.js + Tailwind para um SaaS de agendamento de clínicas com foco em redução de no-show.

## Como rodar

```bash
npm install
npm run dev
```

Abra `http://localhost:3000`.

## Stack

- Next.js (App Router)
- Tailwind CSS
- TypeScript
- lucide-react

## Estrutura

- `app/page.tsx`: landing page principal
- `components/ui.tsx`: componentes reutilizáveis simples
- `app/globals.css`: estilos globais e utilitários de layout

## Ideias para próxima etapa

- Tela de login
- Dashboard autenticado
- Calendário com drag-and-drop
- Funil de confirmação e automações
- Integração com WhatsApp/API de agenda
