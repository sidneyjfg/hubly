import {
  Activity,
  BellRing,
  CalendarDays,
  CheckCircle2,
  Clock3,
  HeartPulse,
  LayoutDashboard,
  MessageSquareMore,
  ShieldCheck,
  SmilePlus,
  Stethoscope,
  Syringe,
  Users,
} from 'lucide-react'
import { Button, SectionHeader } from '@/components/ui'

const specialties = [
  'Odontologia',
  'Dermatologia',
  'Psicologia',
  'Fisioterapia',
  'Estética',
  'Cardiologia',
]

const features = [
  {
    icon: CalendarDays,
    title: 'Agenda multicanal',
    text: 'Website, WhatsApp, telefone e recepção centralizados em um só fluxo para reduzir erros e horários ociosos.',
  },
  {
    icon: BellRing,
    title: 'Lembretes automáticos',
    text: 'Confirmações por WhatsApp, SMS e e-mail com cadência inteligente para reduzir no-show antes da consulta.',
  },
  {
    icon: Clock3,
    title: 'Lista de espera ativa',
    text: 'Preencha cancelamentos em minutos com disparo automático para pacientes compatíveis com o horário.',
  },
  {
    icon: LayoutDashboard,
    title: 'Painel operacional',
    text: 'Acompanhe comparecimento, taxa de ocupação, reagendamentos e performance por unidade e profissional.',
  },
  {
    icon: MessageSquareMore,
    title: 'Comunicação personalizada',
    text: 'Mensagens por tipo de consulta, retorno, exame, primeira visita ou tratamento recorrente.',
  },
  {
    icon: ShieldCheck,
    title: 'Experiência segura',
    text: 'Fluxo pensado para clínicas de diferentes especialidades com acesso simples para equipes administrativas.',
  },
]

const steps = [
  'Paciente agenda em segundos pelo canal preferido.',
  'O sistema envia confirmação e lembretes automáticos.',
  'Em caso de risco de falta, dispara nova tentativa e opções de reagendamento.',
  'Se houver cancelamento, a lista de espera entra em ação para ocupar o horário.',
]

const metrics = [
  { value: '-38%', label: 'redução média de no-show' },
  { value: '+22%', label: 'mais ocupação da agenda' },
  { value: '<2 min', label: 'para confirmar consultas' },
]

const clinicTypes = [
  { icon: Stethoscope, name: 'Clínicas médicas' },
  { icon: SmilePlus, name: 'Odontologia' },
  { icon: HeartPulse, name: 'Especialidades' },
  { icon: Activity, name: 'Exames e diagnóstico' },
  { icon: Syringe, name: 'Estética e bem-estar' },
  { icon: Users, name: 'Redes com múltiplas unidades' },
]

export default function Home() {
  return (
    <main className="overflow-hidden">
      <section className="relative border-b border-line bg-soft">
        <div className="absolute inset-0 bg-grid bg-[size:22px_22px] opacity-50" />
        <div className="container-width relative py-6">
          <header className="flex items-center justify-between rounded-full border border-line bg-white/90 px-5 py-4 backdrop-blur">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-ink text-sm font-semibold text-white">
                CF
              </div>
              <div>
                <p className="text-sm font-semibold">ClinicFlow</p>
                <p className="text-xs text-muted">Scheduling OS para clínicas</p>
              </div>
            </div>
            <nav className="hidden items-center gap-8 text-sm text-slate-600 md:flex">
              <a href="#solucao">Solução</a>
              <a href="#como-funciona">Como funciona</a>
              <a href="#segmentos">Segmentos</a>
              <a href="#contato">Contato</a>
            </nav>
          </header>

          <div className="grid gap-10 py-20 lg:grid-cols-[1.1fr_0.9fr] lg:items-center lg:py-24">
            <div>
              <span className="badge">Menos faltas. Mais agenda preenchida.</span>
              <h1 className="mt-6 max-w-4xl text-5xl font-semibold tracking-tight text-ink md:text-7xl">
                Agendamentos para clínicas que querem reduzir no-show sem complicar a operação.
              </h1>
              <p className="mt-6 max-w-2xl text-lg leading-8 text-muted">
                Um frontend SaaS minimalista para diferentes tipos de clínicas, com foco em confirmação automática,
                lista de espera e experiência fluida para paciente e equipe.
              </p>

              <div className="mt-8 flex flex-wrap gap-3">
                <Button>Solicitar demonstração</Button>
                <Button secondary>Ver a plataforma</Button>
              </div>

              <div className="mt-10 flex flex-wrap gap-3">
                {specialties.map((item) => (
                  <span key={item} className="badge">
                    {item}
                  </span>
                ))}
              </div>
            </div>

            <div className="card p-5 md:p-6">
              <div className="rounded-[28px] border border-slate-200 bg-slate-50 p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted">Painel do dia</p>
                    <h3 className="mt-1 text-xl font-semibold">Unidade Jardins</h3>
                  </div>
                  <span className="rounded-full bg-white px-3 py-1 text-xs font-medium text-slate-600">
                    Atualizado agora
                  </span>
                </div>

                <div className="mt-5 grid gap-4 sm:grid-cols-3">
                  {metrics.map((metric) => (
                    <div key={metric.label} className="rounded-2xl border border-white bg-white p-4">
                      <p className="text-2xl font-semibold text-ink">{metric.value}</p>
                      <p className="mt-1 text-sm text-muted">{metric.label}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-5 rounded-3xl border border-white bg-white p-5">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted">Fluxo de confirmações</p>
                      <p className="mt-1 text-lg font-semibold">Próximas consultas</p>
                    </div>
                    <CheckCircle2 className="text-ink" size={20} />
                  </div>

                  <div className="mt-4 space-y-3">
                    {[
                      ['09:00', 'Retorno • Dermatologia', 'Confirmado'],
                      ['10:30', 'Primeira consulta • Psicologia', 'Lembrete enviado'],
                      ['14:00', 'Avaliação • Odontologia', 'Aguardando resposta'],
                      ['16:15', 'Exame • Cardiologia', 'Lista de espera pronta'],
                    ].map(([time, title, status]) => (
                      <div key={time} className="flex items-center justify-between rounded-2xl border border-slate-100 p-4">
                        <div>
                          <p className="text-sm text-muted">{time}</p>
                          <p className="font-medium text-ink">{title}</p>
                        </div>
                        <span className="rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-700">{status}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="solucao" className="container-width py-24">
        <SectionHeader
          eyebrow="Produto"
          title="Feito para clínicas de vários formatos, com uma experiência simples e elegante."
          copy="A interface foi pensada para funcionar tanto para consultórios independentes quanto para operações com múltiplas unidades, sem perder clareza nem leveza visual."
        />

        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {features.map(({ icon: Icon, title, text }) => (
            <article key={title} className="card p-6">
              <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl bg-soft">
                <Icon size={22} />
              </div>
              <h3 className="text-xl font-semibold">{title}</h3>
              <p className="mt-3 leading-7 text-muted">{text}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="como-funciona" className="border-y border-line bg-soft py-24">
        <div className="container-width grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-start">
          <div>
            <SectionHeader
              eyebrow="Operação inteligente"
              title="Uma jornada desenhada para reduzir faltas antes que elas aconteçam."
              copy="O sistema atua em momentos críticos da agenda para confirmar presença, reativar pacientes e preencher lacunas automaticamente."
            />
          </div>

          <div className="space-y-4">
            {steps.map((step, index) => (
              <div key={step} className="card flex gap-5 p-6">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-ink text-sm font-semibold text-white">
                  0{index + 1}
                </div>
                <p className="pt-2 text-base leading-7 text-slate-700">{step}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="segmentos" className="container-width py-24">
        <SectionHeader
          eyebrow="Versatilidade"
          title="Uma base única para diferentes tipos de clínicas."
          copy="Personalize fluxos, mensagens e agendas por especialidade, unidade ou profissional, mantendo consistência na operação."
        />

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {clinicTypes.map(({ icon: Icon, name }) => (
            <div key={name} className="card flex items-center gap-4 p-5">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-soft">
                <Icon size={22} />
              </div>
              <p className="font-medium text-ink">{name}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="container-width pb-24">
        <div className="card overflow-hidden bg-ink px-6 py-10 text-white md:px-10 md:py-12">
          <div className="grid gap-10 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <span className="inline-flex rounded-full border border-white/20 px-3 py-1 text-sm text-white/80">
                Pronto para escalar
              </span>
              <h2 className="mt-5 max-w-3xl text-3xl font-semibold tracking-tight md:text-5xl">
                Centralize agendamentos, reduza o no-show e eleve a experiência do paciente.
              </h2>
              <p className="mt-4 max-w-2xl text-base leading-7 text-white/70 md:text-lg">
                Uma proposta visual moderna para seu SaaS de clínicas, com linguagem neutra para atender diversos segmentos.
              </p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Button>Começar agora</Button>
              <Button secondary>Falar com vendas</Button>
            </div>
          </div>
        </div>
      </section>

      <footer id="contato" className="border-t border-line py-8">
        <div className="container-width flex flex-col gap-3 text-sm text-muted md:flex-row md:items-center md:justify-between">
          <p>© 2026 ClinicFlow. Frontend conceito para SaaS de agendamento clínico.</p>
          <p>Minimalista, responsivo e construído com Next.js + Tailwind CSS.</p>
        </div>
      </footer>
    </main>
  )
}
