import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'ClinicFlow | SaaS para clínicas',
  description: 'Agendamentos inteligentes para clínicas que reduzem faltas e aumentam a ocupação da agenda.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  )
}
